package nmfc.clients;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleEdge;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RectangularShape;
import java.awt.geom.RoundRectangle2D;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.renderer.category.CategoryItemRendererState;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

public class RoundedBarChartExample extends JFrame {

    public RoundedBarChartExample(String title) {
        super(title);
        JFreeChart chart = createChart(createDataset());
        ChartPanel panel = new ChartPanel(chart);
        panel.setPreferredSize(new Dimension(800, 600));
        setContentPane(panel);
        panel.setMouseWheelEnabled(true); // Enable mouse wheel
        panel.setMouseWheelEnabled(true); // Enable tooltip
    }

    private DefaultCategoryDataset createDataset() {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(1.0, "Category 1", "January");
        dataset.addValue(2.0, "Category 1", "February");
        dataset.addValue(3.0, "Category 1", "March");
        dataset.addValue(4.0, "Category 2", "January");
        dataset.addValue(5.0, "Category 2", "February");
        dataset.addValue(6.0, "Category 2", "March");
        return dataset;
    }

    private JFreeChart createChart(DefaultCategoryDataset dataset) {
        JFreeChart chart = ChartFactory.createBarChart(
                "Rounded Bar Chart Example",
                "Month",
                "Value",
                dataset
        );

        CategoryPlot plot = (CategoryPlot) chart.getPlot();
        plot.setBackgroundPaint(Color.lightGray);

        CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);

        BarRenderer renderer = new RoundedBarRenderer();
        renderer.setSeriesPaint(0, new Color(79, 129, 189)); // Change bar color
        renderer.setBaseToolTipGenerator(new StandardCategoryToolTipGenerator());

        plot.setRenderer(renderer);

        return chart;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            RoundedBarChartExample example = new RoundedBarChartExample("Rounded Bar Chart Example");
            example.pack();
            example.setLocationRelativeTo(null);
            example.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            example.setVisible(true);
        });
    }

    static class RoundedBarRenderer extends BarRenderer {
    	@Override
    	public void drawItem(Graphics2D g2, CategoryItemRendererState state, Rectangle2D dataArea,
    	                     CategoryPlot plot, CategoryAxis domainAxis, ValueAxis rangeAxis,
    	                     CategoryDataset dataset, int row, int column, int pass) {
    	    double x0 = domainAxis.getCategoryMiddle(column, getColumnCount(), dataArea, plot.getDomainAxisEdge());
    	    double y0 = rangeAxis.valueToJava2D(dataset.getValue(row, column).doubleValue(), dataArea, plot.getRangeAxisEdge());
    	    double y1 = rangeAxis.valueToJava2D(0.0, dataArea, plot.getRangeAxisEdge());

    	    Rectangle2D bar = new Rectangle2D.Double(x0 - 10, Math.min(y0, y1), 20, Math.abs(y1 - y0));
    	    RoundRectangle2D roundedBar = new RoundRectangle2D.Double(bar.getX(), bar.getY(), bar.getWidth(), bar.getHeight(), 10, 10);

    	    Paint paint = createGradientPaint(row, bar);
    	    g2.setPaint(paint);
    	    g2.fill(roundedBar);

    	    if (isDrawBarOutline() && state.getBarWidth() > 3) {
    	        g2.setStroke(getItemOutlineStroke(row, column));
    	        g2.setPaint(getItemOutlinePaint(row, column));
    	        g2.draw(roundedBar);
    	    }

    	    // Draw count text on top of the bar
    	    FontMetrics fm = g2.getFontMetrics();
    	    String countText = String.valueOf(dataset.getValue(row, column));
    	    Rectangle2D bounds = fm.getStringBounds(countText, g2);
    	    double textX = bar.getCenterX() - bounds.getWidth() / 2.0;
    	    double textY = bar.getY()- 5; // Place text above the bar with a gap of 5 pixels
    	    g2.setColor(Color.BLACK); // Set text color
    	    g2.drawString(countText, (float) textX, (float) textY);
    	}
    	private Paint createGradientPaint(int row, Rectangle2D bar) {
    	    // Define base colors for each row
    	    Color[] baseColors = {
    	        new Color(135, 206, 250), // Sky Blue
    	        new Color(255, 182, 193), // Light Pink
    	        new Color(152, 251, 152), // Pale Green
    	        new Color(255, 215, 0),   // Gold
    	        new Color(221, 160, 221)  // Plum
    	    };

    	    // Get the base color for the current row
    	    Color baseColor = baseColors[row % baseColors.length];

    	    // Calculate the lighter shade (50% lighter)
    	    Color lightColor = lightenColor(baseColor, 0.5);

    	    // Calculate the darker shade (50% darker)
    	    Color darkColor = darkenColor(baseColor, 0.5);

    	    // Calculate the midpoint of the bar vertically
    	    double midY = bar.getY() + bar.getHeight() / 2.0;

    	    // Create the gradient paint from top to midpoint (50% of the bar height)
    	    return new GradientPaint(
    	            (float) bar.getCenterX(), (float) bar.getY(),
    	            lightColor,
    	            (float) bar.getCenterX(), (float) midY,
    	            darkColor
    	    );
    	}

    	// Helper method to lighten a color by a percentage (0.0 - 1.0)
    	private Color lightenColor(Color color, double percentage) {
    	    float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
    	    float brightness = Math.min(1, hsb[2] + (1 - hsb[2]) * (float) percentage);
    	    return Color.getHSBColor(hsb[0], hsb[1], brightness);
    	}

    	// Helper method to darken a color by a percentage (0.0 - 1.0)
    	private Color darkenColor(Color color, double percentage) {
    	    float[] hsb = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
    	    float brightness = Math.max(0, hsb[2] - hsb[2] * (float) percentage);
    	    return Color.getHSBColor(hsb[0], hsb[1], brightness);
    	}


    }
}
